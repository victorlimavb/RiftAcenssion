#if UNITY_EDITOR
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Riftward.Editor
{
    public static class RiftwardSceneSetup
    {
        private const string SceneFolder = "Assets/Scenes";
        private const string ScenePath = "Assets/Scenes/Arena.unity";

        [MenuItem("Riftward/Criar e Abrir Cena da Arena")]
        public static void CreateArena()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
            {
                Debug.LogWarning("RIFTWARD: pare o Play Mode antes de criar a cena.");
                return;
            }
            // Nunca descartar silenciosamente alteracoes em outras cenas do usuario.
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
            if (!AssetDatabase.IsValidFolder(SceneFolder)) AssetDatabase.CreateFolder("Assets", "Scenes");
            if (AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) != null)
            {
                EditorSceneManager.OpenScene(ScenePath, OpenSceneMode.Single);
            }
            else
            {
                Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                if (!EditorSceneManager.SaveScene(scene, ScenePath))
                {
                    Debug.LogError("RIFTWARD: falha ao salvar Assets/Scenes/Arena.unity");
                    return;
                }
            }
            // Preservar outras cenas do projeto nas Build Settings.
            List<EditorBuildSettingsScene> scenes = new List<EditorBuildSettingsScene>(EditorBuildSettings.scenes);
            bool alreadyInBuild = false;
            for (int i = 0; i < scenes.Count; i++)
            {
                if (scenes[i].path != ScenePath) continue;
                scenes[i] = new EditorBuildSettingsScene(ScenePath, true);
                alreadyInBuild = true;
                break;
            }
            if (!alreadyInBuild) scenes.Insert(0, new EditorBuildSettingsScene(ScenePath, true));
            EditorBuildSettings.scenes = scenes.ToArray();
            AssetDatabase.Refresh();
            Debug.Log("RIFTWARD: cena pronta. Abra a aba Game e aperte Play.");
        }

        [MenuItem("Riftward/Verificar Instalacao e Regras")]
        public static void ValidateInstallation()
        {
            int verified = 0;
            foreach (int count in new[] { 2, 5 })
            {
                foreach (Riftward.Weapon playerWeapon in System.Enum.GetValues(typeof(Riftward.Weapon)))
                {
                    var team = Riftward.ArenaRules.PlayerTeam(count, playerWeapon);
                    if (!Riftward.ArenaRules.ValidTeam(team, count))
                    {
                        Debug.LogError("RIFTWARD: formacao invalida para " + count + "v" + count + " / " + playerWeapon);
                        return;
                    }
                    for (int slot = 0; slot < 3; slot++)
                    {
                        string name = Riftward.ArenaCombat.SkillName(playerWeapon, slot);
                        if (string.IsNullOrEmpty(name))
                        {
                            Debug.LogError("RIFTWARD: habilidade nao encontrada: " + playerWeapon + " / " + slot);
                            return;
                        }
                    }
                    verified++;
                }
                if (!Riftward.ArenaRules.ValidTeam(Riftward.ArenaRules.EnemyTeam(count), count))
                {
                    Debug.LogError("RIFTWARD: composicao dos bots invalida.");
                    return;
                }
            }
            if (Riftward.ArenaRules.ValidTeam(new[] { Riftward.Weapon.Espada, Riftward.Weapon.Arco }, 2) ||
                Riftward.ArenaRules.ValidTeam(new[] { Riftward.Weapon.Aurora, Riftward.Weapon.Aurora }, 2))
            {
                Debug.LogError("RIFTWARD: a regra de DPS + suporte esta falhando.");
                return;
            }
#if !ENABLE_LEGACY_INPUT_MANAGER
            Debug.LogWarning("RIFTWARD: Input Manager antigo esta DESATIVADO. Edit > Project Settings > Player > Active Input Handling: Both (ou Old). Reinicie o Editor.");
#else
            Debug.Log("RIFTWARD: Input Manager antigo habilitado.");
#endif
            Debug.Log("RIFTWARD: " + verified + " formacoes verificadas; 5 armas x 3 habilidades presentes; regras de equipe aprovadas. Esta verificacao NAO testa gameplay ou build.");
        }
    }
}
#endif
