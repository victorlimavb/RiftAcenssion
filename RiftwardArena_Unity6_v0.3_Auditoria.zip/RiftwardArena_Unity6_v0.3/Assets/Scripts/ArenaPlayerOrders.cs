using System.Collections.Generic;
using UnityEngine;

namespace Riftward
{
    // Controle RTS/MOBA: clique direito move/ataca; A+clique move atacando; S para.
    // Q/W/E sao habilidades independentes da movimentacao.
    public sealed class ArenaPlayerOrders
    {
        private enum Order { Stop, Move, AttackTarget, AttackMove }
        private readonly ArenaGame game;
        private readonly ArenaNavigator navigator;
        private readonly List<Vector3> path = new List<Vector3>();
        private ArenaFighter human;
        private ArenaFighter attackTarget;
        private Order order;
        private int index;
        private bool awaitingAttackMove;
        private float nextPathTime;
        private float nextRightHoldTime;
        private Vector3 destination;
        private Vector3 lastPathGoal;

        public ArenaPlayerOrders(ArenaGame owner)
        {
            game = owner;
            navigator = new ArenaNavigator(owner);
        }

        public void Assign(ArenaFighter player)
        {
            human = player;
            Stop();
        }

        public void Stop()
        {
            order = Order.Stop;
            path.Clear();
            index = 0;
            attackTarget = null;
            awaitingAttackMove = false;
            game.HideOrderMarker();
        }

        public void Tick()
        {
            if (human == null || !human.Alive) return;
            if (Input.GetKeyDown(KeyCode.S)) Stop();
            if (Input.GetKeyDown(KeyCode.A)) awaitingAttackMove = true;

            bool onHud = game.PointerOverHud();
            Vector3 cursor = game.MouseGround();
            if (!onHud && Input.GetMouseButtonDown(0) && awaitingAttackMove)
            {
                SetMovement(cursor, true);
                awaitingAttackMove = false;
            }
            if (!onHud && (Input.GetMouseButtonDown(1) ||
                           (Input.GetMouseButton(1) && Time.time >= nextRightHoldTime)))
            {
                nextRightHoldTime = Time.time + 0.12f;
                ArenaFighter foe = game.PickTarget(human, cursor, false, 1.15f);
                if (foe != null)
                {
                    order = Order.AttackTarget;
                    attackTarget = foe;
                    path.Clear();
                    index = 0;
                    nextPathTime = 0f;
                    game.HideOrderMarker();
                }
                else SetMovement(cursor, false);
                awaitingAttackMove = false;
            }

            // Habilidades sao conjuradas apontando o cursor para inimigo, aliado ou solo.
            if (Input.GetKeyDown(KeyCode.Q)) game.Combat.Skill(human, 0, cursor);
            if (Input.GetKeyDown(KeyCode.W)) game.Combat.Skill(human, 1, cursor);
            if (Input.GetKeyDown(KeyCode.E)) game.Combat.Skill(human, 2, cursor);

            if (order == Order.AttackTarget)
            {
                if (attackTarget == null || !attackTarget.Alive) { Stop(); return; }
                if (InAttackPosition(attackTarget))
                {
                    game.Combat.Basic(human, attackTarget);
                    path.Clear();
                    index = 0;
                }
                else FollowMovingTarget(attackTarget.Position);
            }
            else if (order == Order.AttackMove)
            {
                ArenaFighter enemy = FindEnemyInRange();
                if (enemy != null) game.Combat.Basic(human, enemy);
                else FollowPath();
            }
            else if (order == Order.Move) FollowPath();
        }

        private ArenaFighter FindEnemyInRange()
        {
            ArenaFighter chosen = null;
            float nearest = float.PositiveInfinity;
            foreach (ArenaFighter enemy in game.Fighters)
            {
                if (!enemy.Alive || enemy.Faction == human.Faction) continue;
                float d = ArenaCombat.FlatDistance(human.Position, enemy.Position);
                if (d < nearest && d <= human.BasicRange && game.LineOfSight(human.Position, enemy.Position))
                {
                    nearest = d;
                    chosen = enemy;
                }
            }
            return chosen;
        }

        private bool InAttackPosition(ArenaFighter target)
        {
            return ArenaCombat.FlatDistance(human.Position, target.Position) <= human.BasicRange * 0.94f &&
                   game.LineOfSight(human.Position, target.Position);
        }

        private void SetMovement(Vector3 target, bool attackMove)
        {
            order = attackMove ? Order.AttackMove : Order.Move;
            attackTarget = null;
            destination = target;
            Repath(destination);
            game.ShowOrderMarker(path.Count > 0 ? path[path.Count - 1] : human.Position, attackMove);
        }

        private void FollowMovingTarget(Vector3 target)
        {
            if (Time.time >= nextPathTime ||
                (target - lastPathGoal).sqrMagnitude > 0.75f * 0.75f || index >= path.Count)
            {
                Repath(target);
                nextPathTime = Time.time + 0.45f;
            }
            FollowPath();
        }

        // Ao usar dash/rolamento, atualiza a rota a partir da nova posicao.
        public void NotifyDisplaced()
        {
            if (human == null || !human.Alive) return;
            if (order == Order.Move || order == Order.AttackMove) Repath(destination);
            else if (order == Order.AttackTarget && attackTarget != null && attackTarget.Alive)
                Repath(attackTarget.Position);
        }

        private void Repath(Vector3 target)
        {
            path.Clear();
            path.AddRange(navigator.Route(human.Position, target));
            lastPathGoal = target;
            index = 0;
        }

        private void FollowPath()
        {
            while (index < path.Count)
            {
                Vector3 displacement = path[index] - human.Position;
                displacement.y = 0f;
                float distance = displacement.magnitude;
                if (distance <= 0.16f) { index++; continue; }
                float dt = Mathf.Min(Time.deltaTime, distance / human.Speed);
                game.Move(human, displacement, dt);
                return;
            }
            if (order == Order.Move || order == Order.AttackMove)
            {
                order = Order.Stop;
                game.HideOrderMarker();
            }
        }
    }
}
