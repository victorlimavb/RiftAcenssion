using System.Collections.Generic;
using UnityEngine;

namespace Riftward
{
    // A* em uma grade pequena para click-to-move sem dependencia do NavMesh.
    // Cada passo e validado contra a colisao logica da arena.
    public sealed class ArenaNavigator
    {
        private const float Step = 0.5f;
        private const float MinX = -9.5f;
        private const float MinZ = -7f;
        private const int Width = 39;
        private const int Height = 29;
        private const int Count = Width * Height;
        private readonly ArenaGame game;

        public ArenaNavigator(ArenaGame owner) { game = owner; }

        private static int Id(int x, int z) { return z * Width + x; }
        private static Vector3 World(int id)
        {
            return new Vector3(MinX + (id % Width) * Step, 0f, MinZ + (id / Width) * Step);
        }

        private static int NearestCell(Vector3 point)
        {
            int x = Mathf.Clamp(Mathf.RoundToInt((point.x - MinX) / Step), 0, Width - 1);
            int z = Mathf.Clamp(Mathf.RoundToInt((point.z - MinZ) / Step), 0, Height - 1);
            return Id(x, z);
        }

        private int NearestWalkableCell(Vector3 world)
        {
            int original = NearestCell(world);
            if (game.IsWalkable(World(original))) return original;
            int best = -1;
            float bestDistance = float.PositiveInfinity;
            for (int i = 0; i < Count; i++)
            {
                Vector3 point = World(i);
                if (!game.IsWalkable(point)) continue;
                float d = (point - world).sqrMagnitude;
                if (d < bestDistance) { bestDistance = d; best = i; }
            }
            return best;
        }

        private static float Heuristic(int from, int to)
        {
            int ax = from % Width, az = from / Width;
            int bx = to % Width, bz = to / Width;
            float dx = Mathf.Abs(ax - bx), dz = Mathf.Abs(az - bz);
            return (dx + dz) + (1.41421356f - 2f) * Mathf.Min(dx, dz);
        }

        public List<Vector3> Route(Vector3 from, Vector3 clickedDestination)
        {
            List<Vector3> route = new List<Vector3>();
            from.y = 0f;
            clickedDestination.y = 0f;
            Vector3 exactGoal = clickedDestination;
            if (game.IsWalkable(exactGoal) && game.WalkLine(from, exactGoal))
            {
                route.Add(exactGoal);
                return route;
            }

            int origin = NearestWalkableCell(from);
            int goal = NearestWalkableCell(clickedDestination);
            if (origin < 0 || goal < 0) return route;

            float[] g = new float[Count];
            float[] f = new float[Count];
            int[] previous = new int[Count];
            bool[] closed = new bool[Count];
            bool[] isOpen = new bool[Count];
            for (int i = 0; i < Count; i++)
            {
                g[i] = float.PositiveInfinity;
                f[i] = float.PositiveInfinity;
                previous[i] = -1;
            }
            List<int> open = new List<int> { origin };
            isOpen[origin] = true;
            g[origin] = 0f;
            f[origin] = Heuristic(origin, goal);

            while (open.Count > 0)
            {
                int bestIndex = 0;
                for (int i = 1; i < open.Count; i++)
                    if (f[open[i]] < f[open[bestIndex]]) bestIndex = i;
                int current = open[bestIndex];
                open.RemoveAt(bestIndex);
                isOpen[current] = false;
                if (current == goal) break;
                closed[current] = true;

                int cx = current % Width, cz = current / Width;
                for (int dx = -1; dx <= 1; dx++)
                for (int dz = -1; dz <= 1; dz++)
                {
                    if (dx == 0 && dz == 0) continue;
                    int nx = cx + dx, nz = cz + dz;
                    if (nx < 0 || nx >= Width || nz < 0 || nz >= Height) continue;
                    int neighbor = Id(nx, nz);
                    if (closed[neighbor] || !game.IsWalkable(World(neighbor))) continue;
                    // Proibe cortar o canto de um pilar em diagonal.
                    if (dx != 0 && dz != 0 &&
                        (!game.IsWalkable(World(Id(cx + dx, cz))) ||
                         !game.IsWalkable(World(Id(cx, cz + dz))))) continue;
                    float cost = g[current] + ((dx != 0 && dz != 0) ? 1.41421356f : 1f);
                    if (cost >= g[neighbor]) continue;
                    previous[neighbor] = current;
                    g[neighbor] = cost;
                    f[neighbor] = cost + Heuristic(neighbor, goal);
                    if (!isOpen[neighbor]) { isOpen[neighbor] = true; open.Add(neighbor); }
                }
            }

            if (goal != origin && previous[goal] < 0) return route;
            List<Vector3> raw = new List<Vector3>();
            int node = goal;
            while (node != origin && node >= 0)
            {
                raw.Add(World(node));
                node = previous[node];
            }
            raw.Reverse();
            if (raw.Count == 0) raw.Add(World(goal));

            // Remove waypoints desnecessarios sem atravessar obstaculos.
            Vector3 cursor = from;
            int next = 0;
            while (next < raw.Count)
            {
                int furthest = next;
                for (int j = next + 1; j < raw.Count; j++)
                {
                    if (game.WalkLine(cursor, raw[j])) furthest = j;
                }
                route.Add(raw[furthest]);
                cursor = raw[furthest];
                next = furthest + 1;
            }
            if (game.IsWalkable(exactGoal) && game.WalkLine(cursor, exactGoal)) route.Add(exactGoal);
            return route;
        }
    }
}
