using UnityEngine;

namespace Riftward
{
    // Dados de combate independentes de componentes e prefabs.
    public sealed class ArenaFighter
    {
        public GameObject Object;
        public GameObject Crown;
        public Faction Faction;
        public Weapon Weapon;
        public bool IsHuman;
        public string Name;
        public float MaxHP;
        public float HP;
        public float Shield;
        public float ShieldUntil;
        public float ProtectionUntil;
        public float SlowUntil;
        public float NextBasic;
        public readonly float[] NextSkill = new float[3];
        public float NextThink;
        public float NextDotTick;
        public int DotTicks;
        public float DotDamage;
        public ArenaFighter DotSource;
        public bool Alive { get { return HP > 0f; } }
        public Vector3 Position { get { return Object.transform.position; } }
        public float HPFraction { get { return Mathf.Clamp01(HP / MaxHP); } }
        public float Speed { get { return Time.time < SlowUntil ? 3.0f : 4.5f; } }
        public float BasicRange { get { return (Weapon == Weapon.Espada || Weapon == Weapon.Machado) ? 2.5f : 10.5f; } }
        public float BasicDamage
        {
            get
            {
                switch (Weapon)
                {
                    case Weapon.Aurora: return 6f;
                    case Weapon.Espada: return 10f;
                    case Weapon.Machado: return 11f;
                    case Weapon.Arco: return 9f;
                    default: return 8f;
                }
            }
        }
    }
}
