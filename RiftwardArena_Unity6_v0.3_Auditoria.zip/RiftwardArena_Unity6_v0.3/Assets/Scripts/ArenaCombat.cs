using System.Collections.Generic;
using UnityEngine;

namespace Riftward
{
    // Dano, cura e habilidades são calculados no mesmo lugar.
    public sealed class ArenaCombat
    {
        private readonly ArenaGame game;
        public ArenaCombat(ArenaGame gameInstance) { game = gameInstance; }

        public static string SkillName(Weapon weapon, int index)
        {
            string[][] labels = {
                new [] { "Investida", "Aparar", "Redemoinho" },
                new [] { "Luz Vital", "Protecao", "Santuario" },
                new [] { "Flecha Precisa", "Chuva de Flechas", "Rolamento" },
                new [] { "Praga", "Campo Sombrio", "Colheita" },
                new [] { "Corte Amplo", "Furia", "Ruptura" }
            };
            return labels[(int)weapon][index];
        }

        private static float Cooldown(Weapon weapon, int index)
        {
            float[][] times = {
                new [] { 5f, 11f, 10f },
                new [] { 2.8f, 9f, 12f },
                new [] { 4f, 8f, 10f },
                new [] { 3f, 9f, 11f },
                new [] { 4f, 10f, 12f }
            };
            return times[(int)weapon][index];
        }

        public bool Basic(ArenaFighter caster, ArenaFighter target)
        {
            if (!Ready(caster) || target == null || !target.Alive || caster.Faction == target.Faction ||
                Time.time < caster.NextBasic ||
                FlatDistance(caster.Position, target.Position) > caster.BasicRange || !game.LineOfSight(caster.Position, target.Position)) return false;
            caster.NextBasic = Time.time + (caster.Weapon == Weapon.Arco ? 0.85f : 1.05f);
            Damage(target, caster.BasicDamage, caster);
            game.Beam(caster.Position, target.Position, new Color(1f, 0.84f, 0.36f));
            return true;
        }

        public bool Skill(ArenaFighter caster, int slot, Vector3 aim)
        {
            if (!Ready(caster) || slot < 0 || slot > 2 || Time.time < caster.NextSkill[slot]) return false;
            bool applied = false;
            ArenaFighter enemy = game.PickTarget(caster, aim, false, 3.0f);
            ArenaFighter friend = game.PickTarget(caster, aim, true, 3.0f);
            switch (caster.Weapon)
            {
                case Weapon.Espada:
                    if (slot == 0)
                    {
                        Vector3 target = aim;
                        if (enemy != null) target = enemy.Position;
                        if (FlatDistance(caster.Position, target) > 0.4f)
                        {
                            game.Dash(caster, target, 3.9f);
                            foreach (ArenaFighter victim in game.InRadius(caster.Position, 2.2f, Opposing(caster)))
                                Damage(victim, 20f, caster);
                            game.Pulse(caster.Position, 2.2f, Color.yellow);
                            applied = true;
                        }
                    }
                    else if (slot == 1)
                    {
                        caster.ProtectionUntil = Time.time + 2.7f;
                        game.Pulse(caster.Position, 1.1f, Color.cyan);
                        applied = true;
                    }
                    else
                    {
                        foreach (ArenaFighter victim in game.InRadius(caster.Position, 3.0f, Opposing(caster))) Damage(victim, 19f, caster);
                        game.Pulse(caster.Position, 3.0f, Color.yellow);
                        applied = true;
                    }
                    break;
                case Weapon.Aurora:
                    if (slot == 0)
                    {
                        if (friend == null) friend = game.MostInjuredAlly(caster, 9f);
                        if (friend != null && FlatDistance(caster.Position, friend.Position) <= 9f && game.LineOfSight(caster.Position, friend.Position))
                        {
                            Heal(friend, 25f);
                            game.Beam(caster.Position, friend.Position, Color.green);
                            applied = true;
                        }
                    }
                    else if (slot == 1)
                    {
                        if (friend == null) friend = game.MostInjuredAlly(caster, 9f);
                        if (friend != null && FlatDistance(caster.Position, friend.Position) <= 9f && game.LineOfSight(caster.Position, friend.Position))
                        {
                            friend.Shield = Mathf.Min(38f, friend.Shield + 27f);
                            friend.ShieldUntil = Time.time + 5f;
                            game.Pulse(friend.Position, 1.1f, Color.cyan);
                            applied = true;
                        }
                    }
                    else
                    {
                        foreach (ArenaFighter ally in game.InRadius(caster.Position, 5.0f, caster.Faction)) Heal(ally, 18f);
                        game.Pulse(caster.Position, 5f, Color.green);
                        applied = true;
                    }
                    break;
                case Weapon.Arco:
                    if (slot == 0)
                    {
                        if (enemy != null && FlatDistance(caster.Position, enemy.Position) <= 12.0f && game.LineOfSight(caster.Position, enemy.Position))
                        {
                            Damage(enemy, 24f, caster);
                            game.Beam(caster.Position, enemy.Position, Color.green);
                            applied = true;
                        }
                    }
                    else if (slot == 1)
                    {
                        if (FlatDistance(caster.Position, aim) <= 10f)
                        {
                            game.ScheduleBlast(caster, aim, 2.7f, 25f, 0.85f, false);
                            applied = true;
                        }
                    }
                    else
                    {
                        Vector3 away = caster.Position + (caster.Position - aim).normalized * 4.3f;
                        if (FlatDistance(caster.Position, aim) < 0.15f) away = caster.Position + Vector3.back * 4.3f;
                        game.Dash(caster, away, 4.3f);
                        game.Pulse(caster.Position, 1.2f, Color.green);
                        applied = true;
                    }
                    break;
                case Weapon.Ocaso:
                    if (slot == 0)
                    {
                        if (enemy != null && FlatDistance(caster.Position, enemy.Position) <= 11f && game.LineOfSight(caster.Position, enemy.Position))
                        {
                            Damage(enemy, 12f, caster);
                            enemy.DotTicks = Mathf.Min(6, enemy.DotTicks + 4);
                            enemy.DotDamage = 4f;
                            enemy.DotSource = caster;
                            enemy.NextDotTick = Time.time + 1f;
                            game.Beam(caster.Position, enemy.Position, new Color(0.78f, 0.3f, 1f));
                            applied = true;
                        }
                    }
                    else if (slot == 1)
                    {
                        if (FlatDistance(caster.Position, aim) <= 9.5f)
                        {
                            game.ScheduleBlast(caster, aim, 2.6f, 19f, 0.85f, true);
                            applied = true;
                        }
                    }
                    else
                    {
                        if (enemy != null && FlatDistance(caster.Position, enemy.Position) <= 10f && game.LineOfSight(caster.Position, enemy.Position))
                        {
                            int stacks = enemy.DotTicks;
                            Damage(enemy, 15f + stacks * 4f, caster);
                            enemy.DotTicks = 0;
                            game.Beam(caster.Position, enemy.Position, Color.magenta);
                            applied = true;
                        }
                    }
                    break;
                case Weapon.Machado:
                    if (slot == 0)
                    {
                        foreach (ArenaFighter victim in game.InRadius(caster.Position, 3.1f, Opposing(caster))) Damage(victim, 19f, caster);
                        game.Pulse(caster.Position, 3.1f, new Color(1f, 0.36f, 0.28f));
                        applied = true;
                    }
                    else if (slot == 1)
                    {
                        Heal(caster, 16f);
                        caster.ProtectionUntil = Time.time + 1.5f;
                        game.Pulse(caster.Position, 1.1f, Color.red);
                        applied = true;
                    }
                    else
                    {
                        if (FlatDistance(caster.Position, aim) <= 6f)
                        {
                            game.ScheduleBlast(caster, aim, 2.7f, 29f, 0.9f, true);
                            applied = true;
                        }
                    }
                    break;
            }
            if (applied) caster.NextSkill[slot] = Time.time + Cooldown(caster.Weapon, slot);
            return applied;
        }

        public void TickDots(ArenaFighter actor)
        {
            if (!actor.Alive || actor.DotTicks <= 0 || Time.time < actor.NextDotTick) return;
            actor.NextDotTick += 1f;
            actor.DotTicks--;
            Damage(actor, actor.DotDamage, actor.DotSource);
            game.Pulse(actor.Position, 0.55f, Color.magenta);
        }

        public void Damage(ArenaFighter victim, float amount, ArenaFighter attacker)
        {
            if (!victim.Alive) return;
            if (Time.time < victim.ProtectionUntil) amount *= 0.55f;
            if (victim.Shield > 0f)
            {
                float soaked = Mathf.Min(amount, victim.Shield);
                victim.Shield -= soaked;
                amount -= soaked;
            }
            victim.HP = Mathf.Max(0f, victim.HP - amount);
            if (!victim.Alive)
            {
                victim.Object.transform.localScale = new Vector3(0.8f, 0.22f, 0.8f);
                victim.Object.transform.position = new Vector3(victim.Position.x, 0.2f, victim.Position.z);
                game.Pulse(victim.Position, 1.7f, Color.white);
            }
        }

        public static void Heal(ArenaFighter ally, float amount)
        {
            if (ally.Alive) ally.HP = Mathf.Min(ally.MaxHP, ally.HP + amount);
        }

        private static bool Ready(ArenaFighter caster) { return caster != null && caster.Alive; }
        private static Faction Opposing(ArenaFighter caster) { return caster.Faction == Faction.Azul ? Faction.Vermelho : Faction.Azul; }
        public static float FlatDistance(Vector3 a, Vector3 b)
        {
            a.y = 0f;
            b.y = 0f;
            return Vector3.Distance(a, b);
        }
    }
}
