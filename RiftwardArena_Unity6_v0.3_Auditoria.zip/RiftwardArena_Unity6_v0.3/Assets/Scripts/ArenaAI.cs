using UnityEngine;
using System.Collections.Generic;

namespace Riftward
{
    // Bots deterministas o suficiente para testar classes sem servidor.
    public sealed class ArenaAI
    {
        private readonly ArenaGame game;
        private sealed class BotPath
        {
            public readonly List<Vector3> Waypoints = new List<Vector3>();
            public int Index;
            public Vector3 LastGoal;
            public float NextRepath;
        }

        private readonly ArenaNavigator navigator;
        private readonly Dictionary<ArenaFighter, BotPath> routes = new Dictionary<ArenaFighter, BotPath>();

        public ArenaAI(ArenaGame instance)
        {
            game = instance;
            navigator = new ArenaNavigator(instance);
        }

        public void Reset() { routes.Clear(); }

        public void Tick()
        {
            foreach (ArenaFighter bot in game.Fighters)
            {
                if (bot.IsHuman || !bot.Alive) continue;
                ArenaFighter foe = game.Closest(bot, false);
                if (foe == null) continue;
                if (Time.time >= bot.NextThink)
                {
                    bot.NextThink = Time.time + 0.23f + Random.Range(0f, 0.13f);
                    ChooseActions(bot, foe);
                }
                Walk(bot, foe);
            }
        }

        private void ChooseActions(ArenaFighter bot, ArenaFighter foe)
        {
            float distance = ArenaCombat.FlatDistance(bot.Position, foe.Position);
            if (ArenaRules.IsSupport(bot.Weapon))
            {
                ArenaFighter patient = game.MostInjuredAlly(bot, 9f);
                if (patient != null)
                {
                    if (patient.HPFraction < 0.91f) game.Combat.Skill(bot, 0, patient.Position);
                    if (patient.HPFraction < 0.68f && patient.Shield < 5f) game.Combat.Skill(bot, 1, patient.Position);
                    int injured = 0;
                    foreach (ArenaFighter ally in game.InRadius(bot.Position, 5f, bot.Faction))
                        if (ally.HPFraction < 0.73f) injured++;
                    if (injured >= 2 || (bot.HPFraction < 0.3f && injured >= 1)) game.Combat.Skill(bot, 2, bot.Position);
                }
                game.Combat.Basic(bot, foe);
                return;
            }

            switch (bot.Weapon)
            {
                case Weapon.Espada:
                    if (distance > 1.9f && distance < 6.5f) game.Combat.Skill(bot, 0, foe.Position);
                    if (bot.HPFraction < 0.65f) game.Combat.Skill(bot, 1, bot.Position);
                    if (distance < 3f) game.Combat.Skill(bot, 2, foe.Position);
                    break;
                case Weapon.Arco:
                    if (distance < 3.8f) game.Combat.Skill(bot, 2, foe.Position);
                    if (distance < 9.8f) game.Combat.Skill(bot, 1, foe.Position);
                    game.Combat.Skill(bot, 0, foe.Position);
                    break;
                case Weapon.Ocaso:
                    if (foe.DotTicks >= 2) game.Combat.Skill(bot, 2, foe.Position);
                    if (distance < 9.5f) game.Combat.Skill(bot, 1, foe.Position);
                    game.Combat.Skill(bot, 0, foe.Position);
                    break;
                case Weapon.Machado:
                    if (bot.HPFraction < 0.68f) game.Combat.Skill(bot, 1, bot.Position);
                    if (distance < 3.1f) game.Combat.Skill(bot, 0, foe.Position);
                    if (distance < 6f) game.Combat.Skill(bot, 2, foe.Position);
                    break;
            }
            game.Combat.Basic(bot, foe);
        }

        private void Walk(ArenaFighter bot, ArenaFighter foe)
        {
            Vector3 displacement = foe.Position - bot.Position;
            displacement.y = 0f;
            float distance = displacement.magnitude;
            Vector3 goal = bot.Position;
            bool shouldMove = false;
            if (ArenaRules.IsSupport(bot.Weapon))
            {
                ArenaFighter partner = game.Closest(bot, true);
                if (distance < 3.6f)
                {
                    goal = bot.Position - displacement.normalized * 3.2f;
                    shouldMove = true;
                }
                else if (partner != null && ArenaCombat.FlatDistance(bot.Position, partner.Position) > 4.7f)
                {
                    goal = partner.Position;
                    shouldMove = true;
                }
                else if (partner == null && distance > 8f)
                {
                    goal = foe.Position;
                    shouldMove = true;
                }
            }
            else
            {
                float ideal = (bot.Weapon == Weapon.Espada || bot.Weapon == Weapon.Machado) ? 1.7f : 6.6f;
                bool blocked = !game.LineOfSight(bot.Position, foe.Position);
                if (distance > ideal + 0.4f || blocked)
                {
                    goal = foe.Position;
                    shouldMove = true;
                }
                else if (distance < ideal - 1.9f)
                {
                    goal = bot.Position - displacement.normalized * 2.8f;
                    shouldMove = true;
                }
            }

            if (!shouldMove) return;
            BotPath route;
            if (!routes.TryGetValue(bot, out route))
            {
                route = new BotPath();
                routes.Add(bot, route);
            }
            // O mesmo A* do jogador impede que os bots fiquem presos ao contornar pilares.
            if (Time.time >= route.NextRepath ||
                (goal - route.LastGoal).sqrMagnitude > 0.8f || route.Index >= route.Waypoints.Count)
            {
                route.Waypoints.Clear();
                route.Waypoints.AddRange(navigator.Route(bot.Position, goal));
                route.LastGoal = goal;
                route.Index = 0;
                route.NextRepath = Time.time + 0.5f + Random.Range(0f, 0.14f);
            }
            while (route.Index < route.Waypoints.Count)
            {
                Vector3 delta = route.Waypoints[route.Index] - bot.Position;
                delta.y = 0f;
                float length = delta.magnitude;
                if (length < 0.14f) { route.Index++; continue; }
                game.Move(bot, delta, Mathf.Min(Time.deltaTime, length / bot.Speed));
                break;
            }
        }
    }
}
