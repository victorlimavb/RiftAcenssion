using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace Riftward
{
    // Protótipo local 3D. Nenhum prefab ou asset de terceiros é necessário.
    public sealed class ArenaGame : MonoBehaviour
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        private static void Boot()
        {
            if (FindFirstObjectByType<ArenaGame>() == null)
                new GameObject("RIFTWARD - Runtime").AddComponent<ArenaGame>();
        }

        private sealed class TimedVisual
        {
            public GameObject Obj;
            public float End;
            public float Duration;
            public Vector3 InitialScale;
        }

        private sealed class PendingArea
        {
            public ArenaFighter Caster;
            public Vector3 Position;
            public float Radius;
            public float Damage;
            public float When;
            public bool Slow;
            public GameObject Marker;
        }

        private readonly List<ArenaFighter> fighters = new List<ArenaFighter>();
        private readonly List<TimedVisual> visuals = new List<TimedVisual>();
        private readonly List<PendingArea> areas = new List<PendingArea>();
        private readonly List<GameObject> actorObjects = new List<GameObject>();
        private readonly List<Rect> pillarRects = new List<Rect>();
        // Um material por cor (em vez de alocar um material por objeto/efeito).
        private readonly Dictionary<Color, Material> materialCache = new Dictionary<Color, Material>();
        private Camera arenaCamera;
        private ArenaCombat combat;
        private ArenaAI ai;
        private ArenaPlayerOrders orders;
        private GameObject orderMarker;
        private ArenaFighter human;
        private Weapon chosenWeapon = Weapon.Espada;
        private int teamSize = 2;
        private GamePhase phase = GamePhase.Lobby;
        private float matchEnd;
        private string finalMessage = "";
        private string lobbyError = "";
        private GUIStyle titleStyle, headingStyle, normalStyle, smallStyle, centeredStyle;

        public IList<ArenaFighter> Fighters { get { return fighters; } }
        public ArenaCombat Combat { get { return combat; } }
        public GamePhase Phase { get { return phase; } }

        private void Awake()
        {
            combat = new ArenaCombat(this);
            ai = new ArenaAI(this);
            orders = new ArenaPlayerOrders(this);
            InitCamera();
            MakeArena();
        }

        private void InitCamera()
        {
            arenaCamera = Camera.main;
            if (arenaCamera == null)
            {
                GameObject cameraObject = new GameObject("Camera - Top Down");
                arenaCamera = cameraObject.AddComponent<Camera>();
                cameraObject.tag = "MainCamera";
            }
            arenaCamera.transform.position = new Vector3(0f, 28f, 0f);
            arenaCamera.transform.rotation = Quaternion.Euler(90f, 0f, 0f);
            arenaCamera.orthographic = true;
            arenaCamera.clearFlags = CameraClearFlags.SolidColor;
            arenaCamera.backgroundColor = new Color(0.065f, 0.085f, 0.13f);
            arenaCamera.nearClipPlane = 0.1f;
            arenaCamera.farClipPlane = 80f;
            AdjustCamera();

            GameObject sun = new GameObject("Arena Lighting");
            Light lightSource = sun.AddComponent<Light>();
            lightSource.type = LightType.Directional;
            lightSource.intensity = 1.5f;
            lightSource.transform.rotation = Quaternion.Euler(55f, -30f, 0f);
            RenderSettings.ambientLight = new Color(0.52f, 0.56f, 0.67f);
        }

        private void AdjustCamera()
        {
            if (arenaCamera != null)
                arenaCamera.orthographicSize = Mathf.Max(9.4f, 11.3f / Mathf.Max(0.5f, arenaCamera.aspect));
        }

        private Material GetMaterial(Color tint)
        {
            Material found;
            if (materialCache.TryGetValue(tint, out found) && found != null) return found;

            // Mantem suporte ao Built-in e ao URP, sem dependencia de namespace URP.
            // HDRP fica como compatibilidade visual basica, sem garantia de material final.
            var pipeline = GraphicsSettings.currentRenderPipeline;
            string pipelineName = pipeline == null ? "" : pipeline.GetType().Name;
            Shader shader = null;
            if (pipelineName.Contains("Universal")) shader = Shader.Find("Universal Render Pipeline/Lit");
            else if (pipelineName.Contains("HDRender")) shader = Shader.Find("HDRP/Lit");
            else if (pipeline == null) shader = Shader.Find("Standard");
            if (shader == null) shader = Shader.Find("Unlit/Color");
            if (shader == null) shader = Shader.Find("Sprites/Default");
            if (shader == null)
            {
                Debug.LogError("RIFTWARD: nenhum shader compativel encontrado no Render Pipeline ativo.");
                return null;
            }
            Material mat = new Material(shader);
            if (mat.HasProperty("_BaseColor")) mat.SetColor("_BaseColor", tint);
            if (mat.HasProperty("_Color")) mat.SetColor("_Color", tint);
            materialCache.Add(tint, mat);
            return mat;
        }

        private void OnDestroy()
        {
            // Materiais criados em runtime precisam ser liberados ao sair do Play Mode.
            foreach (Material material in materialCache.Values)
                if (material != null) Destroy(material);
            materialCache.Clear();
        }

        private GameObject Shape(PrimitiveType type, string name, Vector3 pos, Vector3 scale, Color color, Transform parent = null)
        {
            GameObject go = GameObject.CreatePrimitive(type);
            go.name = name;
            go.transform.position = pos;
            go.transform.localScale = scale;
            if (parent != null) go.transform.SetParent(parent, true);
            Renderer renderer = go.GetComponent<Renderer>();
            renderer.sharedMaterial = GetMaterial(color);
            Collider collider = go.GetComponent<Collider>();
            if (collider != null) Destroy(collider);
            return go;
        }

        private void MakeArena()
        {
            Shape(PrimitiveType.Cube, "Arena - Floor", new Vector3(0f, -0.36f, 0f), new Vector3(20.8f, 0.6f, 15.9f), new Color(0.13f, 0.17f, 0.24f));
            Color edge = new Color(0.25f, 0.56f, 0.69f);
            Shape(PrimitiveType.Cube, "Borda norte", new Vector3(0f, 0.2f, 7.85f), new Vector3(21f, 0.6f, 0.25f), edge);
            Shape(PrimitiveType.Cube, "Borda sul", new Vector3(0f, 0.2f, -7.85f), new Vector3(21f, 0.6f, 0.25f), edge);
            Shape(PrimitiveType.Cube, "Borda leste", new Vector3(10.35f, 0.2f, 0f), new Vector3(0.25f, 0.6f, 15.8f), edge);
            Shape(PrimitiveType.Cube, "Borda oeste", new Vector3(-10.35f, 0.2f, 0f), new Vector3(0.25f, 0.6f, 15.8f), edge);

            for (int i = -9; i <= 9; i += 3)
                Shape(PrimitiveType.Cube, "Linha vertical", new Vector3(i, -0.048f, 0f), new Vector3(0.035f, 0.015f, 15.1f), new Color(0.19f, 0.23f, 0.3f));
            for (int i = -6; i <= 6; i += 3)
                Shape(PrimitiveType.Cube, "Linha horizontal", new Vector3(0f, -0.048f, i), new Vector3(19.8f, 0.015f, 0.035f), new Color(0.19f, 0.23f, 0.3f));

            CreatePillar(-3.8f);
            CreatePillar(3.8f);
            Shape(PrimitiveType.Cylinder, "Selo central", new Vector3(0f, -0.028f, 0f), new Vector3(2.8f, 0.015f, 2.8f), new Color(0.23f, 0.32f, 0.44f));
            Shape(PrimitiveType.Cylinder, "Spawn azul", new Vector3(-7.65f, -0.025f, 0f), new Vector3(2.5f, 0.016f, 2.5f), new Color(0.1f, 0.29f, 0.4f));
            Shape(PrimitiveType.Cylinder, "Spawn vermelho", new Vector3(7.65f, -0.025f, 0f), new Vector3(2.5f, 0.016f, 2.5f), new Color(0.43f, 0.14f, 0.19f));
        }

        private void CreatePillar(float z)
        {
            pillarRects.Add(new Rect(-1.02f, z - 1.02f, 2.04f, 2.04f));
            Shape(PrimitiveType.Cube, "Pilar - cobertura", new Vector3(0f, 0.9f, z), new Vector3(2.04f, 1.8f, 2.04f), new Color(0.38f, 0.37f, 0.49f));
            Shape(PrimitiveType.Cube, "Pilar - acabamento", new Vector3(0f, 1.84f, z), new Vector3(2.3f, 0.16f, 2.3f), new Color(0.58f, 0.55f, 0.66f));
        }

        private void StartMatch()
        {
            List<Weapon> blue = ArenaRules.PlayerTeam(teamSize, chosenWeapon);
            List<Weapon> red = ArenaRules.EnemyTeam(teamSize);
            if (!ArenaRules.ValidTeam(blue, teamSize) || !ArenaRules.ValidTeam(red, teamSize))
            {
                lobbyError = "Composicao invalida: cada equipe precisa de DPS + suporte.";
                return;
            }
            ClearMatch();
            for (int i = 0; i < teamSize; i++)
            {
                ArenaFighter ally = Spawn(blue[i], Faction.Azul, i, i == 0);
                if (i == 0) human = ally;
                Spawn(red[i], Faction.Vermelho, i, false);
            }
            orderMarker = Shape(PrimitiveType.Cylinder, "Marcador de comando", new Vector3(0f, 0.04f, 0f),
                new Vector3(0.65f, 0.025f, 0.65f), new Color(0.15f, 0.93f, 0.88f));
            actorObjects.Add(orderMarker);
            orderMarker.SetActive(false);
            orders.Assign(human);
            matchEnd = Time.time + 180f;
            phase = GamePhase.Combat;
            lobbyError = "";
        }

        private ArenaFighter Spawn(Weapon weapon, Faction side, int index, bool humanPlayer)
        {
            float z = (index - (teamSize - 1) * 0.5f) * (teamSize == 2 ? 3.3f : 2.3f);
            float x = side == Faction.Azul ? -7.5f : 7.5f;
            Color tint = side == Faction.Azul ? new Color(0.2f, 0.65f, 0.96f) : new Color(0.98f, 0.31f, 0.37f);
            if (humanPlayer) tint = new Color(0.18f, 0.96f, 0.93f);
            GameObject unit = Shape(PrimitiveType.Capsule, (humanPlayer ? "VOCE - " : "BOT - ") + ArenaRules.WeaponName(weapon),
                new Vector3(x, 1f, z), Vector3.one, tint);
            GameObject emblem = Shape(PrimitiveType.Sphere, "Classe", new Vector3(x, 2.2f, z), Vector3.one * 0.56f, ClassColor(weapon), unit.transform);
            Shape(PrimitiveType.Cube, "Direcao", new Vector3(x + (side == Faction.Azul ? 0.56f : -0.56f), 1.05f, z),
                new Vector3(0.22f, 0.22f, 0.22f), Color.white, unit.transform);
            actorObjects.Add(unit);
            ArenaFighter fighter = new ArenaFighter
            {
                Object = unit, Crown = emblem, Faction = side, Weapon = weapon,
                IsHuman = humanPlayer, Name = humanPlayer ? "VOCE" : (side == Faction.Azul ? "ALIADO" : "RIVAL") + " " + (index + 1),
                MaxHP = ArenaRules.IsSupport(weapon) ? 118f : 135f,
                NextThink = Time.time + Random.Range(0f, 0.25f)
            };
            fighter.HP = fighter.MaxHP;
            fighters.Add(fighter);
            return fighter;
        }

        public static Color ClassColor(Weapon weapon)
        {
            switch (weapon)
            {
                case Weapon.Espada: return new Color(1f, 0.85f, 0.3f);
                case Weapon.Aurora: return new Color(0.38f, 1f, 0.6f);
                case Weapon.Arco: return new Color(0.64f, 0.92f, 0.27f);
                case Weapon.Ocaso: return new Color(0.75f, 0.43f, 1f);
                default: return new Color(1f, 0.43f, 0.25f);
            }
        }

        private void ClearMatch()
        {
            foreach (GameObject go in actorObjects) if (go != null) Destroy(go);
            foreach (TimedVisual fx in visuals) if (fx.Obj != null) Destroy(fx.Obj);
            foreach (PendingArea area in areas) if (area.Marker != null) Destroy(area.Marker);
            actorObjects.Clear(); fighters.Clear(); visuals.Clear(); areas.Clear(); human = null;
            orderMarker = null;
            if (orders != null) orders.Stop();
            if (ai != null) ai.Reset();
        }

        private void Update()
        {
            AdjustCamera();
            TickEffects();
            if (phase != GamePhase.Combat) return;
            // A saida deve interromper imediatamente o frame de combate.
            if (Input.GetKeyDown(KeyCode.Escape)) { ReturnLobby(); return; }
            if (human != null && human.Alive) orders.Tick();
            foreach (ArenaFighter fighter in fighters)
            {
                combat.TickDots(fighter);
                if (fighter.Shield > 0f && Time.time > fighter.ShieldUntil) fighter.Shield = 0f;
            }
            ai.Tick();
            TickAreas();
            CheckEnd();
        }

        public void ReturnToLobby() { ReturnLobby(); }

        public Vector3 MouseGround()
        {
            Ray ray = arenaCamera.ScreenPointToRay(Input.mousePosition);
            Plane plane = new Plane(Vector3.up, Vector3.zero);
            float distance;
            return plane.Raycast(ray, out distance) ? ray.GetPoint(distance) : Vector3.zero;
        }

        // IMGUI nao bloqueia automaticamente o input bruto do mouse.
        public bool PointerOverHud()
        {
            Vector3 m = Input.mousePosition;
            if (m.x < 320f && m.y > Screen.height - 128f) return true;
            if (m.x > Screen.width - 305f && m.y > Screen.height - 128f) return true;
            return m.y < 126f && m.x > (Screen.width - 645f) / 2f && m.x < (Screen.width + 645f) / 2f;
        }

        public void ShowOrderMarker(Vector3 at, bool attacking)
        {
            if (orderMarker == null) return;
            orderMarker.SetActive(true);
            orderMarker.transform.position = new Vector3(at.x, 0.055f, at.z);
            orderMarker.GetComponent<Renderer>().sharedMaterial = GetMaterial(attacking
                ? new Color(1f, 0.62f, 0.22f) : new Color(0.15f, 0.93f, 0.88f));
        }

        public void HideOrderMarker()
        {
            if (orderMarker != null) orderMarker.SetActive(false);
        }

        // Movimento real e por ordens do mouse, como em MOBAs RTS.
        public void Move(ArenaFighter fighter, Vector3 dir, float dt)
        {
            if (!fighter.Alive || dir.sqrMagnitude < 0.001f) return;
            dir.y = 0f;
            dir.Normalize();
            Vector3 old = fighter.Position;
            Vector3 step = dir * fighter.Speed * dt;
            Vector3 proposedX = new Vector3(old.x + step.x, old.y, old.z);
            if (IsWalkable(proposedX)) old = proposedX;
            Vector3 proposedZ = new Vector3(old.x, old.y, old.z + step.z);
            if (IsWalkable(proposedZ)) old = proposedZ;
            fighter.Object.transform.position = old;
            if (dir.sqrMagnitude > 0.001f)
                fighter.Object.transform.rotation = Quaternion.LookRotation(dir, Vector3.up);
        }

        public void Dash(ArenaFighter actor, Vector3 destination, float limit)
        {
            Vector3 delta = destination - actor.Position;
            delta.y = 0f;
            if (delta.sqrMagnitude < 0.01f) return;
            float remaining = Mathf.Min(delta.magnitude, limit);
            Vector3 dir = delta.normalized;
            bool displaced = false;
            while (remaining > 0f)
            {
                float step = Mathf.Min(0.25f, remaining);
                Vector3 test = actor.Position + dir * step;
                if (!IsWalkable(test)) break;
                actor.Object.transform.position = test;
                displaced = true;
                remaining -= step;
            }
            if (displaced && actor.IsHuman && orders != null) orders.NotifyDisplaced();
        }

        public bool IsWalkable(Vector3 p)
        {
            const float padding = 0.48f;
            if (Mathf.Abs(p.x) > 9.72f || Mathf.Abs(p.z) > 7.18f) return false;
            foreach (Rect rect in pillarRects)
                if (p.x > rect.xMin - padding && p.x < rect.xMax + padding &&
                    p.z > rect.yMin - padding && p.z < rect.yMax + padding) return false;
            return true;
        }

        // Teste de caminho para suavizar waypoints do A* sem cortar cantos.
        public bool WalkLine(Vector3 a, Vector3 b)
        {
            a.y = 0f; b.y = 0f;
            float length = Vector3.Distance(a, b);
            int samples = Mathf.Max(1, Mathf.CeilToInt(length / 0.18f));
            for (int i = 0; i <= samples; i++)
                if (!IsWalkable(Vector3.Lerp(a, b, i / (float)samples))) return false;
            return true;
        }

        public bool LineOfSight(Vector3 a, Vector3 b)
        {
            Vector2 origin = new Vector2(a.x, a.z);
            Vector2 destination = new Vector2(b.x, b.z);
            foreach (Rect rect in pillarRects)
            {
                // Segmento contra AABB, sem depender de colliders/fisica.
                float tmin = 0f, tmax = 1f;
                Vector2 direction = destination - origin;
                if (!ClipAxis(origin.x, direction.x, rect.xMin, rect.xMax, ref tmin, ref tmax)) continue;
                if (!ClipAxis(origin.y, direction.y, rect.yMin, rect.yMax, ref tmin, ref tmax)) continue;
                return false;
            }
            return true;
        }

        private static bool ClipAxis(float origin, float direction, float min, float max, ref float tmin, ref float tmax)
        {
            if (Mathf.Abs(direction) < 0.0001f) return origin >= min && origin <= max;
            float near = (min - origin) / direction;
            float far = (max - origin) / direction;
            if (near > far) { float temporary = near; near = far; far = temporary; }
            tmin = Mathf.Max(tmin, near);
            tmax = Mathf.Min(tmax, far);
            return tmin <= tmax;
        }

        public ArenaFighter PickTarget(ArenaFighter caster, Vector3 aim, bool ally, float aimTolerance)
        {
            ArenaFighter result = null;
            float best = aimTolerance;
            foreach (ArenaFighter other in fighters)
            {
                if (!other.Alive || (ally ? other.Faction != caster.Faction : other.Faction == caster.Faction)) continue;
                float distance = ArenaCombat.FlatDistance(other.Position, aim);
                if (distance <= best) { best = distance; result = other; }
            }
            return result;
        }

        public ArenaFighter Closest(ArenaFighter caster, bool ally)
        {
            ArenaFighter target = null;
            float best = float.PositiveInfinity;
            foreach (ArenaFighter other in fighters)
            {
                if (!other.Alive || (ally ? other.Faction != caster.Faction : other.Faction == caster.Faction)) continue;
                if (other == caster) continue;
                float distance = ArenaCombat.FlatDistance(caster.Position, other.Position);
                if (distance < best) { best = distance; target = other; }
            }
            return target;
        }

        public ArenaFighter MostInjuredAlly(ArenaFighter caster, float range)
        {
            ArenaFighter target = null;
            float missingBest = -1f;
            foreach (ArenaFighter other in fighters)
            {
                if (!other.Alive || other.Faction != caster.Faction || ArenaCombat.FlatDistance(other.Position, caster.Position) > range) continue;
                float missing = other.MaxHP - other.HP;
                if (missing > missingBest) { target = other; missingBest = missing; }
            }
            return target;
        }

        public List<ArenaFighter> InRadius(Vector3 point, float radius, Faction side)
        {
            List<ArenaFighter> result = new List<ArenaFighter>();
            foreach (ArenaFighter unit in fighters)
                if (unit.Alive && unit.Faction == side && ArenaCombat.FlatDistance(point, unit.Position) <= radius) result.Add(unit);
            return result;
        }

        public void ScheduleBlast(ArenaFighter caster, Vector3 point, float radius, float damage, float delay, bool slows)
        {
            point.y = 0.045f;
            Color tint = caster.Faction == Faction.Azul ? new Color(0.17f, 0.53f, 0.63f) : new Color(0.67f, 0.24f, 0.29f);
            GameObject marker = Shape(PrimitiveType.Cylinder, "Telegraph - saia da area", point,
                new Vector3(radius * 2f, 0.028f, radius * 2f), tint);
            areas.Add(new PendingArea { Caster = caster, Position = point, Radius = radius, Damage = damage,
                When = Time.time + delay, Slow = slows, Marker = marker });
        }

        private void TickAreas()
        {
            for (int i = areas.Count - 1; i >= 0; i--)
            {
                PendingArea area = areas[i];
                if (Time.time < area.When) continue;
                Faction enemySide = area.Caster.Faction == Faction.Azul ? Faction.Vermelho : Faction.Azul;
                foreach (ArenaFighter victim in InRadius(area.Position, area.Radius, enemySide))
                {
                    combat.Damage(victim, area.Damage, area.Caster);
                    if (area.Slow) victim.SlowUntil = Time.time + 2f;
                }
                Pulse(area.Position, area.Radius, Color.white);
                if (area.Marker != null) Destroy(area.Marker);
                areas.RemoveAt(i);
            }
        }

        public void Pulse(Vector3 pos, float radius, Color color)
        {
            GameObject obj = Shape(PrimitiveType.Cylinder, "Efeito - pulso", new Vector3(pos.x, 0.07f, pos.z),
                new Vector3(radius * 2f, 0.025f, radius * 2f), color);
            visuals.Add(new TimedVisual { Obj = obj, End = Time.time + 0.32f, Duration = 0.32f, InitialScale = obj.transform.localScale });
        }

        public void Beam(Vector3 from, Vector3 to, Color color)
        {
            Vector3 difference = to - from;
            difference.y = 0f;
            if (difference.magnitude < 0.1f) { Pulse(to, 0.7f, color); return; }
            Vector3 midpoint = (from + to) * 0.5f;
            midpoint.y = 1.15f;
            GameObject obj = Shape(PrimitiveType.Cube, "Efeito - feixe", midpoint,
                new Vector3(0.16f, 0.14f, difference.magnitude), color);
            obj.transform.rotation = Quaternion.LookRotation(difference.normalized, Vector3.up);
            visuals.Add(new TimedVisual { Obj = obj, End = Time.time + 0.15f, Duration = 0.15f, InitialScale = obj.transform.localScale });
        }

        private void TickEffects()
        {
            for (int i = visuals.Count - 1; i >= 0; i--)
            {
                TimedVisual vfx = visuals[i];
                float timeLeft = vfx.End - Time.time;
                if (timeLeft <= 0f) { if (vfx.Obj != null) Destroy(vfx.Obj); visuals.RemoveAt(i); }
                else if (vfx.Obj != null)
                {
                    float ratio = Mathf.Clamp01(timeLeft / vfx.Duration);
                    vfx.Obj.transform.localScale = new Vector3(vfx.InitialScale.x * (0.8f + 0.2f * ratio),
                        vfx.InitialScale.y, vfx.InitialScale.z * (0.8f + 0.2f * ratio));
                }
            }
        }

        private void CheckEnd()
        {
            int allies = 0, enemies = 0;
            float blueHP = 0f, redHP = 0f;
            foreach (ArenaFighter f in fighters)
            {
                if (f.Faction == Faction.Azul) { if (f.Alive) allies++; blueHP += f.HPFraction; }
                else { if (f.Alive) enemies++; redHP += f.HPFraction; }
            }
            if (allies > 0 && enemies > 0 && Time.time < matchEnd) return;
            if (allies == 0 && enemies == 0) finalMessage = "EMPATE";
            else if (enemies == 0) finalMessage = "VITORIA AZUL";
            else if (allies == 0) finalMessage = "VITORIA VERMELHA";
            else if (Mathf.Abs(blueHP - redHP) < 0.01f) finalMessage = "EMPATE POR TEMPO";
            else finalMessage = blueHP > redHP ? "VITORIA AZUL POR TEMPO" : "VITORIA VERMELHA POR TEMPO";
            phase = GamePhase.Result;
        }

        private void ReturnLobby() { ClearMatch(); phase = GamePhase.Lobby; }

        private void InitGuiStyles()
        {
            if (titleStyle != null) return;
            titleStyle = new GUIStyle(GUI.skin.label) { fontSize = 28, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter, wordWrap = true };
            headingStyle = new GUIStyle(GUI.skin.label) { fontSize = 19, fontStyle = FontStyle.Bold, wordWrap = true };
            normalStyle = new GUIStyle(GUI.skin.label) { fontSize = 14, wordWrap = true };
            smallStyle = new GUIStyle(GUI.skin.label) { fontSize = 11, wordWrap = true };
            centeredStyle = new GUIStyle(GUI.skin.label) { fontSize = 15, alignment = TextAnchor.MiddleCenter, wordWrap = true };
        }

        private void OnGUI()
        {
            InitGuiStyles();
            if (phase == GamePhase.Lobby) DrawLobby();
            else { DrawHud(); if (phase == GamePhase.Result) DrawResult(); }
        }

        private void DrawLobby()
        {
            float width = Mathf.Min(670f, Screen.width - 24f);
            float height = Mathf.Min(565f, Screen.height - 20f);
            float x = (Screen.width - width) * 0.5f;
            float y = (Screen.height - height) * 0.5f;
            GUI.Box(new Rect(x, y, width, height), "");
            GUI.Label(new Rect(x + 14f, y + 12f, width - 28f, 45f), "RIFTWARD: ARENA", titleStyle);
            GUI.Label(new Rect(x + 16f, y + 62f, width - 32f, 45f), "Protótipo PvP tatico: uma arena, cinco armas, classes com funcoes claras.", centeredStyle);
            GUI.Label(new Rect(x + 18f, y + 116f, width - 36f, 28f), "1. Escolha a arma", headingStyle);
            Weapon[] weapons = { Weapon.Espada, Weapon.Aurora, Weapon.Arco, Weapon.Ocaso, Weapon.Machado };
            float buttonsWidth = (width - 36f) / 5f;
            for (int i = 0; i < weapons.Length; i++)
            {
                Weapon w = weapons[i];
                GUI.color = w == chosenWeapon ? ClassColor(w) : Color.white;
                string text = w == Weapon.Aurora ? "AURORA\nSUPORTE" : ArenaRules.WeaponName(w).ToUpperInvariant() + "\nDANO";
                if (GUI.Button(new Rect(x + 18f + i * buttonsWidth, y + 148f, buttonsWidth - 4f, 58f), text)) chosenWeapon = w;
            }
            GUI.color = Color.white;
            GUI.Label(new Rect(x + 18f, y + 218f, width - 36f, 55f),
                "Classe: " + ArenaRules.WeaponName(chosenWeapon) + "   |   Papel: " + (ArenaRules.IsSupport(chosenWeapon) ? "SUPORTE (cura e escudo)" : "DANO") +
                "\n" + Description(chosenWeapon), normalStyle);
            GUI.Label(new Rect(x + 18f, y + 287f, width - 36f, 27f), "2. Escolha o modo", headingStyle);
            if (GUI.Button(new Rect(x + 18f, y + 323f, (width - 45f) / 2f, 43f), teamSize == 2 ? "[X] 2v2" : "2v2")) teamSize = 2;
            if (GUI.Button(new Rect(x + 27f + (width - 45f) / 2f, y + 323f, (width - 45f) / 2f, 43f), teamSize == 5 ? "[X] 5v5" : "5v5")) teamSize = 5;
            GUI.Label(new Rect(x + 18f, y + 375f, width - 36f, 60f),
                "Regra obrigatoria: cada equipe tem ao menos 1 SUPORTE e 1 DANO.\n" +
                "Sua equipe: " + TeamDescription(ArenaRules.PlayerTeam(teamSize, chosenWeapon)), smallStyle);
            GUI.color = new Color(0.59f, 0.95f, 0.76f);
            if (GUI.Button(new Rect(x + 18f, y + height - 91f, width - 36f, 52f), "INICIAR PARTIDA CONTRA BOTS")) StartMatch();
            GUI.color = Color.white;
            GUI.Label(new Rect(x + 18f, y + height - 35f, width - 36f, 29f),
                string.IsNullOrEmpty(lobbyError) ? "Clique direito: mover/atacar  |  A + clique esquerdo: atacar ao mover  |  S: parar  |  Q/W/E: habilidades" : lobbyError, smallStyle);
        }

        private static string Description(Weapon weapon)
        {
            switch (weapon)
            {
                case Weapon.Espada: return "Curta distancia. Investida, aparar dano, redemoinho.";
                case Weapon.Aurora: return "A principal ferramenta de suporte. Cura, escudos e santuario.";
                case Weapon.Arco: return "Dano de longa distancia. Precisao, area e mobilidade.";
                case Weapon.Ocaso: return "Dano de maldicao ao longo do tempo, zonas e explosao de praga.";
                default: return "Pressao corpo a corpo. Corte amplo, furia e ruptura.";
            }
        }

        private static string TeamDescription(IList<Weapon> team)
        {
            List<string> names = new List<string>();
            foreach (Weapon weapon in team) names.Add(ArenaRules.WeaponName(weapon));
            return string.Join(" + ", names.ToArray());
        }

        private void DrawHud()
        {
            int blue = 0, red = 0;
            foreach (ArenaFighter f in fighters) if (f.Alive) { if (f.Faction == Faction.Azul) blue++; else red++; }
            GUI.Box(new Rect(12f, 12f, 305f, 108f), "");
            GUI.Label(new Rect(22f, 18f, 278f, 28f), "RIFTWARD   " + teamSize + "v" + teamSize, headingStyle);
            GUI.Label(new Rect(22f, 49f, 278f, 21f), "AZUL " + blue + "   x   " + red + " VERMELHO", normalStyle);
            GUI.Label(new Rect(22f, 73f, 278f, 24f), "Tempo: " + Mathf.CeilToInt(Mathf.Max(0f, matchEnd - Time.time)) + "s", normalStyle);
            GUI.Box(new Rect(Screen.width - 293f, 12f, 280f, 105f), "");
            GUI.Label(new Rect(Screen.width - 284f, 18f, 260f, 89f),
                "Direito: andar / atacar inimigo\nA + esquerdo: atacar ao mover | S: parar\nQ / W / E: habilidades (aponte o mouse)", smallStyle);
            DrawWorldBars();
            if (human == null) return;
            float hudWidth = Mathf.Min(620f, Screen.width - 24f);
            float x = (Screen.width - hudWidth) * 0.5f;
            float y = Screen.height - 116f;
            GUI.Box(new Rect(x, y, hudWidth, 107f), "");
            GUI.Label(new Rect(x + 11f, y + 8f, hudWidth - 20f, 23f),
                ArenaRules.WeaponName(human.Weapon) + "  |  VIDA: " + Mathf.CeilToInt(human.HP) + "/" + human.MaxHP +
                "  |  ESCUDO: " + Mathf.CeilToInt(human.Shield), normalStyle);
            string[] keys = { "Q", "W", "E" };
            for (int i = 0; i < 3; i++)
            {
                float w = (hudWidth - 24f) / 3f;
                Rect r = new Rect(x + 11f + i * w, y + 37f, w - 5f, 51f);
                float remaining = Mathf.Max(0f, human.NextSkill[i] - Time.time);
                GUI.color = remaining > 0 ? Color.gray : ClassColor(human.Weapon);
                GUI.Box(r, keys[i] + " - " + ArenaCombat.SkillName(human.Weapon, i) + "\n" +
                    (remaining > 0f ? remaining.ToString("0.0") + "s" : "PRONTO"));
            }
            GUI.color = Color.white;
        }

        private void DrawWorldBars()
        {
            foreach (ArenaFighter f in fighters)
            {
                if (!f.Alive) continue;
                Vector3 position = arenaCamera.WorldToScreenPoint(f.Position + Vector3.up * 2.2f);
                if (position.z <= 0f) continue;
                float x = position.x - 36f;
                float y = Screen.height - position.y - 23f;
                if (y < 0 || y > Screen.height - 45f) continue;
                GUI.color = Color.white;
                GUI.Label(new Rect(x - 12f, y - 16f, 100f, 18f), f.IsHuman ? "VOCE" : (ArenaRules.IsSupport(f.Weapon) ? "HEALER" : ArenaRules.WeaponName(f.Weapon)), smallStyle);
                GUI.color = new Color(0.14f, 0.14f, 0.16f);
                GUI.DrawTexture(new Rect(x, y, 72f, 9f), Texture2D.whiteTexture);
                GUI.color = f.Faction == Faction.Azul ? new Color(0.18f, 0.85f, 0.92f) : new Color(1f, 0.3f, 0.36f);
                GUI.DrawTexture(new Rect(x, y, 72f * f.HPFraction, 9f), Texture2D.whiteTexture);
                if (f.Shield > 0f)
                {
                    GUI.color = Color.cyan;
                    GUI.DrawTexture(new Rect(x, y + 10f, 72f * Mathf.Clamp01(f.Shield / 40f), 3f), Texture2D.whiteTexture);
                }
                GUI.color = Color.white;
            }
        }

        private void DrawResult()
        {
            float width = Mathf.Min(445f, Screen.width - 18f);
            float x = (Screen.width - width) / 2f;
            float y = (Screen.height - 204f) / 2f;
            GUI.Box(new Rect(x, y, width, 204f), "");
            GUI.Label(new Rect(x + 12f, y + 24f, width - 24f, 53f), finalMessage, titleStyle);
            GUI.Label(new Rect(x + 12f, y + 91f, width - 24f, 24f), "Partida encerrada. Reorganize sua estrategia.", centeredStyle);
            if (GUI.Button(new Rect(x + 30f, y + 137f, width - 60f, 44f), "VOLTAR A SELECAO")) ReturnLobby();
        }
    }
}
