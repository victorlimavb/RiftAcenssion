using System.Collections.Generic;

namespace Riftward
{
    public enum Weapon { Espada, Aurora, Arco, Ocaso, Machado }
    public enum Faction { Azul, Vermelho }
    public enum GamePhase { Lobby, Combat, Result }

    // Uma arma de suporte inicial. O sistema aceita outras no futuro.
    public static class ArenaRules
    {
        public static bool IsSupport(Weapon weapon) { return weapon == Weapon.Aurora; }

        public static string WeaponName(Weapon weapon)
        {
            switch (weapon)
            {
                case Weapon.Espada: return "Espada";
                case Weapon.Aurora: return "Cajado da Aurora";
                case Weapon.Arco: return "Arco";
                case Weapon.Ocaso: return "Cajado do Ocaso";
                default: return "Machado";
            }
        }

        public static bool ValidTeam(IList<Weapon> team, int teamSize)
        {
            if (team == null || team.Count != teamSize || (teamSize != 2 && teamSize != 5)) return false;
            int damage = 0, support = 0;
            foreach (Weapon weapon in team)
            {
                if (IsSupport(weapon)) support++; else damage++;
            }
            return support >= 1 && damage >= 1;
        }

        public static List<Weapon> PlayerTeam(int teamSize, Weapon player)
        {
            List<Weapon> result = new List<Weapon> { player };
            if (teamSize == 2)
            {
                result.Add(IsSupport(player) ? Weapon.Espada : Weapon.Aurora);
            }
            else if (teamSize == 5)
            {
                if (!IsSupport(player)) result.Add(Weapon.Aurora);
                Weapon[] damage = { Weapon.Espada, Weapon.Arco, Weapon.Ocaso, Weapon.Machado };
                foreach (Weapon weapon in damage)
                {
                    if (result.Count >= teamSize) break;
                    if (weapon != player) result.Add(weapon);
                }
            }
            return result;
        }

        public static List<Weapon> EnemyTeam(int teamSize)
        {
            if (teamSize == 2) return new List<Weapon> { Weapon.Machado, Weapon.Aurora };
            return new List<Weapon> { Weapon.Espada, Weapon.Aurora, Weapon.Arco, Weapon.Ocaso, Weapon.Machado };
        }
    }
}
