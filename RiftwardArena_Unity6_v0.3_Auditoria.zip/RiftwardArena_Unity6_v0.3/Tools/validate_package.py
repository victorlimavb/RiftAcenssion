"""Independent offline packaging checks. Not a Unity compiler or runtime test."""
from pathlib import Path
import re
import json

root = Path(__file__).resolve().parents[1]
source = root / 'Assets' / 'Scripts'
files = list(source.glob('*.cs'))
assert len(files) == 7, f'Expected 7 runtime C# files, found {len(files)}'
assert (root/'Assets/Editor/RiftwardSceneSetup.cs').is_file()
manifest = json.loads((root/'Packages/manifest.json').read_text())
assert 'dependencies' in manifest

# Strip comments and quoted strings before checking braces for basic syntax hygiene.
def strip_strings_comments(text):
    pattern = r'//[^\n]*|/\*[\s\S]*?\*/|@"(?:[^"]|"")*"|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\''
    return re.sub(pattern, lambda m: ' '*len(m.group()), text)

for path in [*files, root/'Assets/Editor/RiftwardSceneSetup.cs']:
    source_code = strip_strings_comments(path.read_text(encoding='utf-8'))
    for open_char,close_char in [('(',')'),('[',']'),('{','}')]:
        stack=[]
        for i, char in enumerate(source_code):
            if char==open_char: stack.append(i)
            elif char==close_char:
                assert stack, f'{path.name}: unexpected {close_char} at {i}'
                stack.pop()
        assert not stack, f'{path.name}: missing {close_char}'

rules = (source/'ArenaRules.cs').read_text()
assert 'support >= 1 && damage >= 1' in rules
assert 'teamSize != 2 && teamSize != 5' in rules
input_code = (source/'ArenaPlayerOrders.cs').read_text()
for key in ('KeyCode.Q', 'KeyCode.W', 'KeyCode.E', 'KeyCode.A', 'KeyCode.S', 'GetMouseButtonDown(1)'):
    assert key in input_code, f'Missing RTS binding {key}'
assert 'KeyCode.D' not in input_code
arena_code = (source/'ArenaGame.cs').read_text()
assert 'private void TickPlayer()' not in arena_code
assert 'ArenaNavigator' in (source/'ArenaNavigator.cs').read_text()
assert 'WalkLine' in arena_code
assert '"Q", "W", "E"' in arena_code
print(f'PASS: {len(files)} runtime scripts, editor setup, dependency manifest, lexical brace check, role and RTS input checks.')
print('NOT TESTED: Unity compilation, run-time behavior, builds or network play.')

# Guards for specific regressions found in audit v0.3.
assert 'if (Input.GetKeyDown(KeyCode.Escape)) { ReturnLobby(); return; }' in arena_code
assert 'materialCache' in arena_code and 'Destroy(material)' in arena_code
assert 'orders.NotifyDisplaced()' in arena_code
assert 'navigator.Route(bot.Position, goal)' in (source/'ArenaAI.cs').read_text()
assert 'Verificar Instalacao e Regras' in (root/'Assets/Editor/RiftwardSceneSetup.cs').read_text()
print('PASS: v0.3 regressions checked: escape, material cache, dash re-path, bot routing, Unity menu diagnostics.')
