# RIFTWARD: ARENA — protótipo Unity 6 (v0.3 - revisada)

**Jogo independente de combate tático em arena, inspirado no gênero de Hellgates.** Este pacote contém código-fonte C#, estrutura de projeto Unity e um gerador de cena. Não utiliza artes, mapas, código ou nomes de habilidades de Albion Online.

> **Estado de verificação:** os scripts e a estrutura foram revisados fora do Unity. Como o Editor Unity não está instalado no ambiente usado para montar o pacote, **não foi possível compilar ou executar uma partida no Editor**. Considere isto uma versão de teste revisada; veja a seção de diagnóstico se aparecer uma mensagem vermelha no Console.

## 1. O que já existe

- Arena 3D top-down com pilares que bloqueiam movimento e linha de visão.
- Seleção entre cinco armas: **Espada**, **Cajado da Aurora** (suporte Holy), **Arco**, **Cajado do Ocaso** (magia de maldição), **Machado**.
- Cada arma possui um ataque básico e **três habilidades (Q, W, E)**.
- **2v2 e 5v5**; os dois times são validados para exigir **pelo menos um DPS e um suporte**. A composição restante é completada por bots.
- Bots aliados/inimigos com rotas A*, combate, dano, escudo, cura, DoT, slow, indicações de área e resultado da partida.
- **Movimentação estilo RTS/MOBA (League of Legends)**: ordens do mouse, pathfinding A*, perseguir/atacar automaticamente.
- Sem pacotes de Asset Store ou dependências de terceiros.

**Ainda não existe:** multiplayer online, matchmaking, partidas reais contra outras pessoas, visual final, efeitos sonoros ou conexão de contas.

## 2. Preparar o Unity no Windows

1. Instale/abra **Unity Hub**: https://unity.com/download.
2. Faça login com sua conta Unity. Sua assinatura é vinculada a essa conta; não é necessário inserir serial no protótipo.
3. Em **Installs > Install Editor**, instale **Unity 6.3 LTS** (revisão 6000.3.x atualizada) como base estável. A versão 6.6 é a atualização estável mais recente publicada até 14/10/2026; a 0.3 visa compatibilidade com ela, mas não foi compilada nessa versão. Se já usa uma revisão Unity 6 compatível, tente abrir nela primeiro; o Hub poderá solicitar uma migração.
4. Descompacte `RiftwardArena_Unity6_v0.3_Auditoria.zip` num diretório com caminho curto, por exemplo `C:\UnityProjects\RiftwardArena_Unity6`.
5. O diretório correto deve conter as subpastas **Assets**, **Packages** e **ProjectSettings**. Não abra o arquivo `.zip` diretamente.

## 3. Abrir o projeto e gerar a cena

1. No **Unity Hub**, vá a **Projects > Add > Add project from disk** (ou **Open**) e selecione **a pasta extraída** `RiftwardArena_Unity6_v0.3`.
2. Abra com a versão instalada do Unity 6.3 LTS. Aguarde a importação inicial e a compilação dos scripts.
3. Como o protótipo usa `UnityEngine.Input` (API legada), acesse **Edit > Project Settings > Player > Other Settings > Active Input Handling**. Selecione **Both** ou **Input Manager (Old)**. Se o Unity solicitar reinício, reinicie.
4. No menu superior do Unity Editor, escolha **Riftward > Verificar Instalacao e Regras** e depois **Riftward > Criar e Abrir Cena da Arena**. Isso cria a cena `Assets/Scenes/Arena.unity` e a adiciona às cenas habilitadas para build.
5. Abra a guia **Game**. Opcionalmente, use resolução **16:9**, como 1280×720.
6. Clique no botão ▶ **Play** na parte superior. Um menu de escolha de arma/modo aparecerá.
7. Selecione uma das armas, escolha **2v2** ou **5v5** e clique em **INICIAR PARTIDA CONTRA BOTS**.
8. Ao terminar, clique em **VOLTAR A SELEÇÃO**. Para editar scripts, pare o Play no botão ▶.

**Observação:** a primeira vez em que você clica na guia Game pode servir apenas para dar foco à janela.

## 4. Controles — iguais na lógica de movimento de um MOBA

| Ação | Comando |
| --- | --- |
| Andar para o destino | **Clique direito no chão** |
| Emitir ordens continuamente | **Segurar o botão direito** e apontar |
| Atacar um inimigo e persegui-lo até ficar no alcance | **Clique direito no inimigo** |
| Andar atacando qualquer inimigo no alcance (attack-move) | **A** e depois **clique esquerdo no chão** |
| Parar ordem atual | **S** |
| Habilidade 1 | **Q** + cursor no alvo/solo |
| Habilidade 2 | **W** + cursor no alvo/solo |
| Habilidade 3 | **E** + cursor no alvo/solo |
| Voltar ao menu de seleção | **Esc** |

**Não se movimenta com WASD.** O clique direito cria uma rota até o destino, inclusive desviando dos dois pilares. Um marcador no chão mostra o destino; ele fica laranja para attack-move. Ataques básicos exigem alcance e linha de visão. Habilidades são lançadas na posição sob o mouse, exceto autocast/áreas ao redor do jogador conforme a habilidade. O clique esquerdo comum não ataca.

Se jogar de **Cajado da Aurora**, aponte o cursor para um aliado (ou seu próprio personagem) e use **Q** para curar, **W** para dar escudo; **E** cura aliados próximos. Se não houver um aliado reconhecido no alcance, Q/W priorizam um aliado ferido próximo.

## 5. Armas

| Arma | Papel | Q | W | E |
| --- | --- | --- | --- | --- |
| Espada | DPS melee | Investida | Aparar | Redemoinho |
| Cajado da Aurora | **Suporte** | Luz Vital (cura) | Proteção (escudo) | Santuário (cura em área) |
| Arco | DPS ranged | Flecha Precisa | Chuva de Flechas | Rolamento |
| Cajado do Ocaso | DPS magic | Praga (DoT) | Campo Sombrio | Colheita |
| Machado | DPS melee | Corte Amplo | Fúria | Ruptura |

Os números de habilidades são **provisórios**. A primeira meta é avaliar a resposta do controle, a legibilidade e a diversão das lutas locais.

## 6. O código, pasta por pasta

```
RiftwardArena_Unity6/
├── Assets/
│   ├── Editor/RiftwardSceneSetup.cs   # gera uma cena Unity vazia
│   └── Scripts/
│       ├── ArenaGame.cs               # mundo, UI, efeito, condição de vitória
│       ├── ArenaPlayerOrders.cs       # mouse/teclado estilo LoL
│       ├── ArenaNavigator.cs          # rotas A* ao redor de obstáculos
│       ├── ArenaAI.cs                 # controle dos bots
│       ├── ArenaCombat.cs             # ataques, cura e habilidades
│       ├── ArenaFighter.cs            # dados de personagem
│       └── ArenaRules.cs              # papéis e validação das equipes
├── Packages/manifest.json
├── ProjectSettings/ProjectVersion.txt
├── DESIGN.md
├── README_COMECE_AQUI.md
└── .gitignore
```

A cena, câmera, luz, arena, personagens e interfaces são geradas em **runtime** pelo `ArenaGame`; os objetos são formas simples. **Não é necessário importar prefabs**.

## 7. Problemas comuns

- **O menu Riftward não aparece no editor:** acesse **Window > General > Console**. A primeira mensagem vermelha normalmente revela um erro de compilação; envie a mensagem completa.
- **"You are trying to read Input using the UnityEngine.Input class"**: altere **Active Input Handling** para **Both** ou **Input Manager (Old)**, depois reinicie o Editor.
- **O botão Play mostra uma tela vazia:** confirme que gerou/abriu `Assets/Scenes/Arena.unity`, está na guia **Game** e não há erros no Console.
- **Não consigo clicar para andar:** clique uma vez na guia **Game** para dar foco, clique com o botão **direito** no piso da arena e não sobre o HUD.
- **A rota passa para perto de um pilar:** o protótipo utiliza colisão lógica expandida (e não NavMesh). Registre o ponto onde aconteceu para refinarmos o controlador.
- **Materiais aparecem cor-de-rosa:** o código tenta criar materiais compatíveis com o pipeline padrão ou URP. Confira o pipeline 3D do projeto; HDRP não está preparado.
- **Não consigo conjurar:** confirme que apontou o cursor para o alvo/solo, que não está no cooldown e que há alcance/linha de visão.

## 8. Criar `.exe` para Windows (depois de testar no Editor)

1. Vá a **File > Build Profiles** no Unity 6.
2. Selecione/crie perfil **Windows**. Caso falte o módulo, use o Hub para adicionar **Windows Build Support** ao Editor.
3. Confira que `Assets/Scenes/Arena.unity` está entre as cenas habilitadas.
4. Clique em **Build And Run**. Escolha um diretório **fora da pasta Assets**.

## 9. Não perder o trabalho

- Mantenha o ZIP original guardado.
- Preferencialmente, crie um **repositório privado Git/GitHub** e faça commits frequentes.
- Versione **Assets**, **Packages**, **ProjectSettings**, **DESIGN.md** e o guia. Não versione **Library**, **Temp**, **Logs** ou **Builds** (o `.gitignore` incluído já exclui essas pastas).
- Próximo marco real: testar todos os cinco loadouts; em seguida, revisar IA e arquitetura para partidas 2v2 humanas online.

## 10. Auditoria v0.3 (14/10/2026)

Alteracoes feitas apos revisao da v0.2:

1. **ESC**: sair para o lobby agora encerra o update do combate imediatamente; o controlador nao pode concluir uma partida vazia apos sair.
2. **Bots**: usam `ArenaNavigator.Route` e atualizam os caminhos para contornar pilares, em vez de empurrar contra obstaculos sem pathfinding.
3. **Memoria/material**: materiais por cor sao reutilizados e descartados no fim do Play Mode; evita alocacoes de um material para cada objeto ou efeito.
4. **Areas visuais**: tamanho dos circulos de aviso/efeito agora corresponde ao raio calculado no combate.
5. **Dash**: rolamento/investida do jogador atualizam as rotas pendentes a partir da nova posicao.
6. **Editor/seguranca**: criar cena pede para salvar mudancas, preserva outras cenas configuradas para build e nao sobrescreve o seu trabalho silenciosamente.
7. **Menu de diagnostico**: `Riftward > Verificar Instalacao e Regras` valida composicoes de todas as cinco armas em 2v2/5v5, suas 15 habilidades, e avisa se o input legado estiver desligado. O diagnostico so aparece apos os scripts terem compilado.

### Atualizar um projeto aberto na versao anterior

**Recomendacao segura:** pare o Play Mode; faca backup do projeto atual; extraia o ZIP novo num diretorio separado; no Hub, abra o novo projeto e nao mexa no anterior ate validar. Se voce fez mudancas proprias na v0.2, compare seus scripts antes de substituir arquivos.

1. Confirme `Active Input Handling = Both` ou `Old` (ja configurado anteriormente).
2. Abra **Window > General > Console** e limpe os avisos antigos (Clear).
3. Clique em **Riftward > Verificar Instalacao e Regras**. Esperado: 10 formacoes verificadas e regras aprovadas, com Input Manager habilitado.
4. Clique em **Riftward > Criar e Abrir Cena da Arena** e depois em **Play**.
5. Teste cada arma em **2v2** e **5v5**, incluindo movimentos ao redor dos dois pilares, ataques, Q/W/E, Esc e a volta ao lobby.

**Importante:** esses testes de regras nao sao um teste de compilacao externa, de jogo em tempo real, de executavel nem de servidor. Nao ha multiplayer implementado. Se houver erros no Console, envie o texto completo do primeiro erro vermelho junto da revisao do seu Unity (menu Help > About Unity).
