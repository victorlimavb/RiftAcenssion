# Relatorio tecnico: RIFTWARD v0.2 -> v0.3
**Data:** 14 de outubro de 2026

## Resumo
A v0.2 tinha componentes suficientes para uma prova de conceito *no papel*, mas nao havia teste documentado de compilacao ou gameplay no Unity. A v0.3 corrige bugs identificados por inspecao e adiciona verificacao dentro do Editor. **Nao foi compilada nem executada no Unity Editor neste ambiente** (Unity Editor / compilador C# nao instalado).

## Pontos identificados
| Severidade | Defeito v0.2 | Correcao v0.3 |
|---|---|---|
| Alta | Esc dentro de Orders.Tick retornava ao lobby mas Game.Update continuava IA/CheckEnd no mesmo frame; poderia mudar para resultado | Tratamento antecipado de Esc e retorno imediato do Update |
| Media | Bots usavam direcao reta e ficavam presos em pilares | Bots compartilham a mesma navegacao A* e recalculam rotas |
| Media | Material novo para cada objeto e efeito, sem descarte explicito | Cache por cor e descarte em OnDestroy |
| Media | Sinalizador visual dos efeitos AoE tinha metade do raio logico | Cilindros com diametro de 2 x raio |
| Media | Dash do jogador nao refazia rota de ordem em andamento | NotifyDisplaced em ordens do jogador |
| Media | Gerador de cena substituia a lista das cenas de build e nao perguntava por mudancas sem salvar | Dialogo de salvamento e inclusao nao destrutiva da cena |
| Baixa | Sem verificacao de regras por dentro do Unity | Menu 'Verificar Instalacao e Regras' |

## Compatibilidade de Unity
- Unity 6.3 LTS (6000.3): base declarada do projeto, recomendacao de estabilidade para a primeira iteracao.
- Unity 6.6 (6000.6): release Supported publicada em 01/09/2026, a versao mais recente oficialmente identificada ate 14/10/2026. Nao foi comprovada em execucao.
- Input: codigos usam o Input Manager legado; Active Input Handling precisa ser 'Both' ou 'Input Manager (Old)'. Migracao para o novo Input System e um trabalho futuro, nao uma pre-condicao do prototipo.
- Render: Built-in e URP sao considerados; HDRP tem fallback simples, nao validado.

## Escopo e limitacoes
- Funciona conceitualmente como demo local contra bots, nao como multiplayer PvP 2v2/5v5 real.
- O menu diagnostico testa regras, nao performance ou jogabilidade.
- Sem testes de build Windows, testes PlayMode automatizados ou IL2CPP.
- A estrutura ainda nao e adequada para um jogo comercial online sem refatoracao de arquitetura.

## Como validar no computador
1. Abrir a copia v0.3 no Unity Hub com Unity 6.3 LTS ou 6.6.
2. Console sem erros vermelhos = scripts compilados no ambiente do usuario.
3. Menu `Riftward > Verificar Instalacao e Regras`: esperados 10 times validos, 15 habilidades presentes e sistema de Input legado habilitado.
4. Menu `Riftward > Criar e Abrir Cena da Arena`; apertar Play.
5. Testar cada arma em 2v2 e 5v5, 20 partidas curtas: mover ao redor dos pilares, Q/W/E, ataque com clique direito, A + clique esquerdo, S, Esc, vitoria/derrota.
6. Repetir teste de build Windows em `File > Build Profiles` apos passar no Editor.

## Referencias da documentacao
- https://unity.com/releases/unity-6/support
- https://discussions.unity.com/t/unity-6-6-is-now-available/1735357
- https://docs.unity.com/en-us/engine/6000.0/manual/uitoolkits/uielements/uie-support-for-runtime-ui/uie-render-runtime-ui/uie-runtime-event-system
- https://docs.unity.com/en-us/engine/6000.3/manual/materials-and-shaders/built-in/shader-built-in
- https://docs.unity.com/en-us/engine/6000.3/script-reference/unityeditor/scenemanagement/editorscenemanager/savescene
