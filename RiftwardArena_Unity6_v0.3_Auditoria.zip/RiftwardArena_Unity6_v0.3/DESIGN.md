# RIFTWARD: ARENA — Game Design Document v0.2 (RTS/MOBA)

## Identidade e ambição

Jogo independente de **arena PvP de fantasia, câmera top-down e controle RTS/MOBA por mouse**. Usa o tipo de combate tático entre equipes visto em arenas de MMORPGs como referência, sem replicar personagens, nomes, assets ou sistemas proprietários. O objetivo de design é oferecer confrontos mais justos, com regras transparentes e sem grind para tornar uma arma competitiva.

**Pilares**: 1) igualdade de atributos; 2) posicionamento/linha de visão; 3) composição com papéis definidos; 4) contrajogo com alertas visuais; 5) acessibilidade competitiva; 6) partidas rápidas, observáveis e passíveis de replay.

## Mecânica de movimentação definida

- **Clique direito no solo** = mover até o ponto, com A* e desvio de pilares.
- **Clique direito no inimigo** = perseguição e ataques básicos automáticos, respeitando linha de visão, alcance e intervalo entre golpes.
- **A + clique esquerdo no solo** = attack-move: avançar e atacar automaticamente um inimigo válido que entre no alcance.
- **S** = parar a ordem de movimento/ataque atual.
- **Q/W/E** = três habilidades por arma; posicionadas no cursor ou ao redor do próprio personagem, de acordo com a habilidade.
- Sem WASD. Câmera fixa no protótipo; no futuro, câmera seguindo o jogador e scroll de borda opcionais.
- Movimento sem NavMesh por enquanto, pois o mapa é pequeno e estático. Multiplayer futuro **não** deve depender de rota calculada somente no cliente.

## Composição obrigatória

- **2v2**: um DPS + um suporte por equipe.
- **5v5**: pelo menos um DPS e um suporte por equipe (protótipo usa um suporte e quatro DPS).
- Não é permitido iniciar uma equipe fora dessas condições; validação central `ArenaRules.ValidTeam()`.
- Em multiplayer a regra deverá ser imposta **pelo servidor**, e não apenas pela tela de seleção.

## Cinco armas iniciais

| Arma | Função | Q | W | E |
|---|---|---|---|---|
| Espada | pressão melee e aproximação | Investida | Aparar | Redemoinho |
| Cajado da Aurora | Holy healer / proteção | Luz Vital | Proteção | Santuário |
| Arco | pressão ranged / reposicionamento | Flecha Precisa | Chuva de Flechas | Rolamento |
| Cajado do Ocaso | magia de maldição e DoT | Praga | Campo Sombrio | Colheita |
| Machado | bruiser de área | Corte Amplo | Fúria | Ruptura |

A primeira versão contém ataques básicos e três habilidades por arma; não há árvore de equipamento, runas, itens, especializações nem atributos externos. Números ainda sem balanceamento com usuários reais.

## Implementado no protótipo v0.2

- Arena local 3D em primitivas, dois pilares, HP/escudos/slow/DoT, timer de 180s, indicadores de ataques em área e linha de visão.
- Menu para escolher arma e 2v2 ou 5v5; bots preenchem equipes.
- Movimento clique-direito, perseguição e attack-move com navegação A*.
- HUD de cooldowns Q/W/E, barras de HP, marcador de destino e tela de resultado.
- Vitória pela eliminação do time adversário; desempate por soma das frações de HP se o tempo esgotar.

## Fora do escopo — não afirmar que já funciona

PvP pela internet, servidor autoritativo, sincronização, lobby online, matchmaking, premade de cinco jogadores, ranking, replay, câmera móvel, mapa maior, som e arte final, esportes eletrônicos, anticheat, inventário/economia, publicação em lojas.

## Próximos marcos (em ordem)

1. **Consolidar controle mouse**: validar A*, perseguir, parar, attack-move, detecção do alvo, cancelamento e ataques perto de pilares.
2. **Combate legível**: cast times, animações, projéteis, barras de energia, indicadores de direção, status e logs de dano.
3. **Balanceamento local**: criar harness de partidas simuladas, medir TTK, taxa de vitória e impacto da cura.
4. **Arquitetura multiplayer**: separar simulação determinística/simulada de renderização; servidor autoritativo, input commands, snapshot, predição e reconciliação.
5. **Primeiro 2v2 humano online**: lobby, comp obrigatória no servidor, spawn, combate, encerramento, telemetria de latência.
6. **5v5 online + competitivo**: filas por papel, premades, espectador, ranking e replays.
7. **Conteúdo autoral**: modelos, VFX, UI própria, mapas, sons e identidade visual.

## Testes manuais de aceitação v0.2

- Escolher cada uma das cinco armas e entrar em 2v2 e 5v5.
- Confirmar que cada composição de ambos os times tem DPS e suporte.
- Verificar que **W não anda**, mas lança segunda habilidade.
- Verificar que clique direito em ponto atrás de pilar contorna obstáculo.
- Verificar que clique direito em inimigo persegue/ataca até morrer ou receber outra ordem.
- Verificar que `A` + esquerdo vai ao chão e ataca ao encontrar inimigo; `S` interrompe ordens.
- Confirmar que ataques de alvo único não ignoram linha de visão, cura não atinge inimigos e área tem telegraph antes de aplicar dano.
- Confirmar que a batalha encerra por eliminação ou tempo sem erros no Console.


## Revisao de engenharia v0.3 — 14/10/2026

- Alvo de manutencao: Unity 6.3 LTS; checagem documental de APIs ate Unity 6.6; validacao real de 6.6 pendente no Editor.
- Movimento RTS no clique direito e attack-move (A + clique esquerdo); sem WASD.
- Pathfinding A* aplicado ao jogador e aos bots; nao ha NavMesh nem servidor autoritativo.
- Sistema visual inicial usa materiais reutilizados. UI OnGUI e programacao monolitica sao provisoria; iterar para UI Toolkit, ScriptableObjects e animacoes apos teste de combate.
- Habilidades: 15 (3 x 5); composicao tem obrigacao DPS + suporte, mas times ainda sao preenchidos automaticamente.
- Proximo passo: compilar e rodar no Unity Editor; criar testes PlayMode e analisar combate; so depois planejar netcode, simulacao de ticks e matchmaking.
